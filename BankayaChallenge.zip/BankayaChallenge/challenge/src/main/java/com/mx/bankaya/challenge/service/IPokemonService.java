package com.mx.bankaya.challenge.service;

/**
 * Interface that manages the Pokemon information
 * @author Sarahy Ramirez
 */
public interface IPokemonService {

    Object getInformation(String name, String information);
}
